<?php

mail('mobeen.fidele@gmail.com','Test','This is test mail function');

?>